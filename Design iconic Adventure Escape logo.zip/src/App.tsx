import { useEffect, useState } from "react"

/* ─────────────────────────────────────────────────────────────────
   Single color: burnished gold.
   The mountain gains a rounded friendly peak and a sunrise visible
   through the arch — kids see magic, adults see adventure.
───────────────────────────────────────────────────────────────── */

const GOLD = {
  blaze:   "#FFF0A0",
  bright:  "#F5B830",
  mid:     "#D48410",
  warm:    "#A85E08",
  deep:    "#5C2E04",
  glow:    "#FFF9D0",
  sun:     "#FFD050",
  ray:     "#FF8C28",
}

type Variant = "night" | "dusk" | "day"

const VARIANTS: Record<Variant, { bg: string; bgName: string }> = {
  night: { bg: "#0A0D14", bgName: "Night" },
  dusk:  { bg: "#1A1028", bgName: "Dusk"  },
  day:   { bg: "#F5EDD8", bgName: "Day"   },
}

/* Deterministic star positions for the background */
const STARS = Array.from({ length: 52 }, (_, i) => ({
  x:  ((i * 179 + 31)  % 500),
  y:  ((i * 113 + 17)  % 300),
  r:  i % 9 === 0 ? 1.4 : i % 4 === 0 ? 1.0 : 0.55,
  op: 0.08 + (i % 7) * 0.04,
}))

/* 12 sun rays rotated around the sun centre */
const RAY_ANGLES = Array.from({ length: 12 }, (_, i) => i * 30)
const SUN = { cx: 250, cy: 312 }

function LogoMark({
  variant,
  uid,
  hideWordmark = false,
}: {
  variant: Variant
  uid: string
  hideWordmark?: boolean
}) {
  const isDark = variant !== "day"
  const wordmarkColor = isDark ? GOLD.bright : GOLD.deep
  const subColor      = isDark ? GOLD.warm   : GOLD.warm
  const markTop       = isDark ? GOLD.blaze  : GOLD.bright
  const markBase      = isDark ? GOLD.deep   : "#7A4010"

  const gId  = `g-${uid}`
  const glId = `gl-${uid}`
  const grId = `gr-${uid}`
  const haId = `ha-${uid}`

  return (
    <svg
      viewBox="0 0 500 568"
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      aria-label="Adventure Escape SA"
    >
      <defs>
        {/* Mountain gradient */}
        <linearGradient id={gId} x1="0.42" y1="0" x2="0.58" y2="1">
          <stop offset="0%"   stopColor={markTop} />
          <stop offset="30%"  stopColor={GOLD.bright} />
          <stop offset="65%"  stopColor={GOLD.warm} />
          <stop offset="100%" stopColor={markBase} />
        </linearGradient>

        {/* Arch glow */}
        <radialGradient id={glId} cx="250" cy="310" r="110" gradientUnits="userSpaceOnUse">
          <stop offset="0%"   stopColor={GOLD.glow} stopOpacity={isDark ? "0.95" : "0.7"} />
          <stop offset="35%"  stopColor={GOLD.sun}  stopOpacity={isDark ? "0.55" : "0.35"} />
          <stop offset="100%" stopColor={GOLD.ray}  stopOpacity="0" />
        </radialGradient>

        {/* Rock grain */}
        <filter id={grId} x="0%" y="0%" width="100%" height="100%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.78" numOctaves="4" seed="9" stitchTiles="stitch" result="n"/>
          <feColorMatrix type="matrix" in="n"
            values="0 0 0 0 0.38  0 0 0 0 0.38  0 0 0 0 0.38  0 0 0 0.16 0" result="g"/>
          <feComposite in="g" in2="SourceAlpha" operator="in" result="c"/>
          <feBlend in="SourceGraphic" in2="c" mode="multiply"/>
        </filter>

        {/* Soft outer halo */}
        <filter id={haId} x="-28%" y="-28%" width="156%" height="156%">
          <feGaussianBlur stdDeviation="16" result="blur"/>
          <feColorMatrix type="matrix" in="blur"
            values={`1 0.55 0 0 0  0.5 0.35 0 0 0  0 0 0 0 0  0 0 0 ${isDark ? 0.5 : 0.2} 0`}
            result="warm"/>
          <feMerge>
            <feMergeNode in="warm"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>

      {/* ── Stars (only on dark variants, behind everything) ── */}
      {isDark && !hideWordmark && STARS.map((s, i) => (
        <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="white" opacity={s.op} />
      ))}

      {/* ── Arch portal glow layer ── */}
      <ellipse cx={SUN.cx} cy={SUN.cy + 28} rx="120" ry="90"
        fill={`url(#${glId})`} />
      <ellipse cx={SUN.cx} cy={SUN.cy + 8} rx="55" ry="48"
        fill={GOLD.glow}
        opacity={isDark ? "0.38" : "0.22"}
        style={{ filter: "blur(9px)" }} />

      {/* ── Sun rays (behind mountain, visible only through arch) ── */}
      {RAY_ANGLES.map((angle) => (
        <g key={angle} transform={`rotate(${angle}, ${SUN.cx}, ${SUN.cy})`}>
          <path
            d={`M ${SUN.cx - 3.5},${SUN.cy - 28} L ${SUN.cx},${SUN.cy - 78} L ${SUN.cx + 3.5},${SUN.cy - 28} Z`}
            fill={GOLD.ray}
            opacity={isDark ? "0.88" : "0.65"}
          />
        </g>
      ))}

      {/* ── Sun disc ── */}
      <circle cx={SUN.cx} cy={SUN.cy} r={21}
        fill={GOLD.sun}
        opacity={isDark ? "0.96" : "0.8"} />

      {/* ── Depth shadow ── */}
      <path
        d="M 253,72 L 50,394 L 460,394 Z"
        fill={markBase}
        opacity={isDark ? "0.28" : "0.12"}
        transform="translate(0,5)"
      />

      {/* ── Mountain: rounded peak via small dome arc ── */}
      {/*    Outer shape: dome peak A 14,14 + straight sides                */}
      {/*    Inner shape: Gothic arch cutout Q 250,252                       */}
      <path
        fillRule="evenodd"
        d="
          M 238,73
          A 16,16 0 0,0 262,73
          L 455,390 L 45,390 Z
          M 192,390 Q 250,252 308,390 Z
        "
        fill={`url(#${gId})`}
        filter={`url(#${grId}) url(#${haId})`}
      />

      {/* ── Crisp edge highlight stroke ── */}
      <path
        fillRule="evenodd"
        d="
          M 238,73
          A 16,16 0 0,0 262,73
          L 455,390 L 45,390 Z
          M 192,390 Q 250,252 308,390 Z
        "
        fill="none"
        stroke={markTop}
        strokeWidth="0.7"
        opacity={isDark ? "0.3" : "0.2"}
      />

      {/* ── Wordmark ── */}
      {!hideWordmark && (
        <>
          <text
            x="250" y="448"
            textAnchor="middle"
            fontFamily="'Baloo 2', sans-serif"
            fontWeight="900"
            fontSize="40"
            fill={wordmarkColor}
            letterSpacing="4"
          >
            ADVENTURE ESCAPE
          </text>

          <text
            x="250" y="477"
            textAnchor="middle"
            fontFamily="'Nunito', sans-serif"
            fontWeight="300"
            fontSize="11"
            fill={subColor}
            letterSpacing="16"
            dx="8"
          >
            SOUTH AFRICA
          </text>

          <line x1="178" y1="491" x2="322" y2="491"
            stroke={subColor} strokeWidth="0.6" opacity="0.38" />
        </>
      )}
    </svg>
  )
}

export default function App() {
  const [variant, setVariant] = useState<Variant>("night")
  const [key, setKey]         = useState(0)

  /* Re-trigger spring animation on palette change */
  useEffect(() => { setKey((k) => k + 1) }, [variant])

  const bg = VARIANTS[variant].bg

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center gap-10 py-14 px-6 transition-colors duration-700"
      style={{ backgroundColor: bg }}
    >
      {/* ── Hero mark with spring entrance ── */}
      <div
        key={key}
        className="w-72 sm:w-80 md:w-[26rem]"
        style={{ animation: "springIn 0.75s cubic-bezier(0.34,1.56,0.64,1) both" }}
      >
        <LogoMark variant={variant} uid={`hero-${variant}-${key}`} />
      </div>

      {/* ── Scale proof ── */}
      <div
        className="flex items-end gap-5"
        style={{ animation: "fadeUp 0.9s 0.3s both" }}
      >
        {[18, 32, 50].map((sz) => (
          <div key={sz} style={{ width: sz, height: sz }}>
            <LogoMark variant={variant} uid={`sz-${sz}-${variant}`} hideWordmark />
          </div>
        ))}
        <span style={{
          fontFamily: "Nunito, sans-serif",
          fontWeight: 300,
          fontSize: 9,
          letterSpacing: "0.22em",
          textTransform: "uppercase",
          color: GOLD.warm,
          paddingBottom: 2,
          opacity: 0.7,
        }}>
          favicon → icon → mark
        </span>
      </div>

      {/* ── Background variant switcher ── */}
      <div
        className="flex gap-4"
        style={{ animation: "fadeUp 1s 0.5s both" }}
      >
        {(Object.entries(VARIANTS) as [Variant, { bg: string; bgName: string }][]).map(([id, cfg]) => (
          <button
            key={id}
            onClick={() => setVariant(id)}
            className="flex flex-col items-center gap-2 focus:outline-none"
          >
            <div style={{
              width: 54,
              height: 66,
              borderRadius: 14,
              backgroundColor: cfg.bg,
              border: `1px solid ${id === variant ? GOLD.bright : "rgba(255,255,255,0.06)"}`,
              boxShadow: id === variant
                ? `0 0 0 1.5px ${GOLD.warm}, 0 10px 28px rgba(0,0,0,0.45), 0 0 36px ${GOLD.deep}80`
                : "0 2px 10px rgba(0,0,0,0.3)",
              transform: id === variant ? "scale(1.12) translateY(-3px)" : "scale(1)",
              transition: "all 0.4s cubic-bezier(0.34,1.56,0.64,1)",
              overflow: "hidden",
            }}>
              <LogoMark variant={id} uid={`chip-${id}`} hideWordmark />
            </div>
            <span style={{
              fontFamily: "Nunito, sans-serif",
              fontWeight: 400,
              fontSize: 8.5,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: GOLD.warm,
              opacity: id === variant ? 1 : 0.35,
              transition: "opacity 0.3s",
            }}>
              {cfg.bgName}
            </span>
          </button>
        ))}
      </div>

      <style>{`
        @keyframes springIn {
          0%   { opacity: 0; transform: scale(0.78) translateY(20px); }
          60%  { opacity: 1; }
          100% { opacity: 1; transform: scale(1) translateY(0); }
        }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}
